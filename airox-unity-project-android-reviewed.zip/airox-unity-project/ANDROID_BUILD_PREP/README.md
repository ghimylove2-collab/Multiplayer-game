# Airox Android APK Preparation

Detected Unity project:
- Product name: Airox — The Connected Era
- Bundle version: 0.1.0
- Unity version file: ProjectSettings/ProjectVersion.txt
- Packages manifest: present
- ProjectSettings.asset: present

## Build in Unity

1. Open this project with the Unity version declared in `ProjectVersion.txt`.
2. Install Android Build Support + Android SDK & NDK Tools + OpenJDK.
3. Open Build Settings and switch platform to Android.
4. Add `Assets/Scenes/AiroxDemo.unity`.
5. Set a unique package identifier under Player Settings.
6. Set Development Build for the first local test.
7. Build an APK.

## Backend URL

For an Android phone, `localhost` points to the phone itself.
If the backend runs on a PC on the same Wi-Fi, use the PC's LAN IP.
Set the client API base URL to the reachable development address.

## Current limitation

This preparation does not claim that an APK has been compiled. Unity Editor,
Android SDK/NDK and OpenJDK are not available in this file-generation runtime.
