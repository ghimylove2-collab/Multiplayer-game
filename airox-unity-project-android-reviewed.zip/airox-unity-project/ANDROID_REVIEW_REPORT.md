# Airox Unity Android Review

- Unity version: **2022.3.39f1**
- C# scripts: **1**
- Scenes: **1**
- Files: **12**

## Static findings

- No obvious static Android compile blockers were detected by this limited source scan.

## Important
This is a static review only. It does not run Unity's compiler and therefore
cannot certify that the project builds successfully for Android.

A real APK build still requires Unity 2022.3.39f1 with Android Build Support,
SDK/NDK and OpenJDK installed.
